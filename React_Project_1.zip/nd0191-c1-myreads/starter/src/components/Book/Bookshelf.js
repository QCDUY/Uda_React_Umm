import React from "react";
import Card from "./Card";

function Bookshelf(props) {
    const { bookshelfTitle, bookType, data, isUpdate } = props;
    // Custom id for each bookshelf 
    let idByBookType = "";
    if (bookType === "currentlyReading"){
        idByBookType = "current-reading";
    } else if (bookType === "wantToRead"){
        idByBookType = "want-to-read";
    } else {
        idByBookType = "read"
    }
  return (
    <div>
      <div className="bookshelf">
        <h2 className="bookshelf-title" id={idByBookType}>
          {bookshelfTitle}
        </h2>
        <div className="bookshelf-books">
          <ol className="books-grid">
            {data
              .filter((x) => x.shelf === bookType)
              .map((n, i) => (
                <li key={i}>
                  <Card
                    value={n}
                    type={n.shelf}
                    isUpdate={isUpdate}
                  />
                </li>
              ))}
          </ol>
        </div>
      </div>
    </div>
  );
}


export default Bookshelf;