import "@testing-library/jest-dom";
import { fireEvent, render } from "@testing-library/react";
import HomePage from "../Components/Home";
import { Provider } from "react-redux";
import { store } from "../store";
import { BrowserRouter } from "react-router-dom";
import React from "react";
import { get_Questions } from "../Redux/slices/questionSlice";
import { get_InfoUser } from "../Redux/slices/userSlice";
import { loginPage } from "../Redux/slices/loginSlice";

describe("HomePage component", () => {
  it("should render HomePage component correctly", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "tylermcginnis" };
    await store.dispatch(loginPage(auth));
    const component = render(
      <Provider store={store}>
        <BrowserRouter>
          <HomePage />
        </BrowserRouter>
      </Provider>
    );
    expect(component).toBeDefined();
  });

  it("should render title of HomePage Component", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "sarahedo" };
    await store.dispatch(loginPage(auth));
    const wrapper = render(
      <Provider store={store}>
        <BrowserRouter>
          <HomePage />
        </BrowserRouter>
      </Provider>
    );
    const headerElement = wrapper.getByTestId("title");
    expect(headerElement).toHaveTextContent("Dashboard");
  });

  it("should render title of HomePage Component", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "sarahedo" };
    await store.dispatch(loginPage(auth));
    const wrapper = render(
      <Provider store={store}>
        <BrowserRouter>
          <HomePage />
        </BrowserRouter>
      </Provider>
    );
    const headerElement = wrapper.getByTestId("title");
    expect(headerElement).toHaveTextContent("Dashboard");
  });

  it("should render Unanswered Questions of HomePage Component", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "sarahedo" };
    await store.dispatch(loginPage(auth));
    const wrapper = render(
      <Provider store={store}>
        <BrowserRouter>
          <HomePage />
        </BrowserRouter>
      </Provider>
    );
    const headerElement = wrapper.getByTestId("type-question");
    expect(headerElement).toHaveTextContent("Answered Questions");
  });

  it("should render Unanswered Questions of HomePage Component", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "sarahedo" };
    await store.dispatch(loginPage(auth));
    const wrapper = render(
      <Provider store={store}>
        <BrowserRouter>
          <HomePage />
        </BrowserRouter>
      </Provider>
    );
    const headerElement = wrapper.getByTestId("type-question");
    const buttonEl = wrapper.getByTestId("btn-go-to")
    expect(buttonEl).toBeInTheDocument();
    fireEvent.click(buttonEl);
    expect(headerElement).toHaveTextContent("Unanswered Questions");
  });
});


