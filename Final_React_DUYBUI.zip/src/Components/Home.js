import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import Card from "./Card";
import { getQuestionType } from "../Utils/getQuestionType";

function HomePage() {
  const [flag, setFlag] = useState(false);
  const questions = useSelector((state) => state.question.questions);
  const users = useSelector((state) => state.user.userInfo);
  const authenId = useSelector((state) => state.logged.isUserLogged);
  let { newQuestions, answerQuestion } = getQuestionType(
    questions,
    authenId.id
  );
  // Handle view
  function handleView() {
    setFlag(!flag);
  }

  return (
    <div>
      <h1 data-testid="title">Dashboard</h1>
      <div className="new-question mt-4 p-4">
        <button data-testid="btn-go-to" className="btn btn-primary" onClick={(e) => handleView()}>
          Go To {flag ? "Answered Questions " : "Unanswered Questions"}
        </button>
        <h2 data-testid="type-question" className="mt-4">
          # <u>  {!flag ? "Answered Questions " : "Unanswered Questions"} </u>
        </h2>
        {flag ? (
          <div className="row hidden-md-up">
            {newQuestions.length > 0
              ? newQuestions.map((v) => (
                  <div className="col-md-6" key={v.id}>
                    <Card question={v} author={users[v["author"]]} isType={"new"} loggedIn={authenId.id}/>{" "}
                  </div>
                ))
              : null}
          </div>
        ) : (
          <div className="row hidden-md-up">
            {answerQuestion.length > 0
              ? answerQuestion.map((v) => (
                  <div className="col-md-6" key={v.id}>
                    <Card question={v} author={users[v["author"]]} isType={"answer"} loggedIn={authenId.id}/>{" "}
                  </div>
                ))
              : null}
          </div>
        )}
      </div>
    </div>
  );
}

export default HomePage;
