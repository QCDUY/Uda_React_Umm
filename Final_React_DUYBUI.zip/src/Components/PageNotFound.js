import React from "react";
const PageNotFound = (props) => {
    return (
        <div>
            <h1> Error 404 </h1>
            <h2> PAGE NOT FOUND ................. </h2>
           
        </div>
    )
}

export default PageNotFound;