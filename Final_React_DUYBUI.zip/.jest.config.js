module.exports = {
    "testEnvironment": "jsdom"
}