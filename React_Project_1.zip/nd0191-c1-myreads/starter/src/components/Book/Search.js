  import React, { useEffect, useState } from "react";
  import { Link } from "react-router-dom";
  import { search, getAll } from "../../BooksAPI";
  import Card from "./Card";

  function Search() {
    
    const [dataSearch, setDataSearch] = useState([]);
    const [data, setData] = useState([]);
    
    useEffect(()=> {
      return getAllBook();
    }, [data.length]);

    async function getAllBook(){
      await getAll().then((response)=>setData(response))
    }
    
    const checkDataIsExist = (id) => {
      let type = "";
      let isBook = data.filter((v) => v.id === id);
      if (isBook.length > 0) {
        type = isBook[0].shelf;
      }
      return type + "";
    };

    const handleSearch = (keyword) => {
      if (keyword.length > 0) {
        search(keyword, 100).then((res) => {
          if (res.length > 0) {
            setDataSearch(res);
          } else {
            setDataSearch([]);
          }
        });
      } else {
        setDataSearch([]);
      }
    };

    return (
      <div className="search-books">
        <div className="search-books-bar">
          <Link to="/" className="close-search">
            Close
          </Link>
          <div className="search-books-input-wrapper">
            <input
              type="text"
              placeholder="Search by title, author, or ISBN"
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>
        </div>
        {dataSearch?.length > 0 ? (
          <div className="search-books-results">
            <ol className="books-grid">
              {dataSearch?.map((n, i) => (
                <li key={i}>
                  <Card value={n} type={checkDataIsExist(n.id)} />
                </li>
              ))}
            </ol>
          </div>
        ) : (
          null
        )}
      </div>
    );
  }

  export default Search;
