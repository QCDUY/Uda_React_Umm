import React from "react";
import { Link } from "react-router-dom";
const Card = (props) => {
    let showAnswer = ""
    let answer = props.question;
    if (answer.optionOne.votes.includes(props.loggedIn)) {
        showAnswer = answer.optionOne.text;
    } 
    if (answer.optionTwo.votes.includes(props.loggedIn)) {
        showAnswer = answer.optionTwo.text;
    } 

    return (
        <div className="card mt-2">
            <img src={props?.author?.avatarURL} width={200} height={200} className="card-img-top" alt="..." />
            <div className="card-body">
                <h5 className="card-title">{props.question.author}</h5>
                <p className="card-text">{new Date(props.question.timestamp).toDateString()}</p>
                <p>Option 1: {props.question.optionOne.text}</p>
                <p>Option 2: {props.question.optionTwo.text}</p>
                <p className="text-danger"> {props.isType !== "new" ? ("My Answer: " + showAnswer) : ""} </p>
                <Link to={'questions/' + props.question.id} className="btn btn-primary">
                    {props.isType === "new" ? "Answer Poll" : "View Result"}
                </Link>
            </div>
        </div>

    )
}
export default Card;