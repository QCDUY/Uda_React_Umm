import React from "react";
import { update } from "../../BooksAPI";

function Card(props) {
  // Get value from props
  let { title, authors, imageLinks } = props.value;
  let { type } = props;
  // List Options
  const options = [
    { value: "currentlyReading", title: "Currently Reading" },
    { value: "wantToRead", title: "Want To Read" },
    { value: "read", title: "Read" },
    { value: "none", title: "None" },
  ];

  const handleOnSelect = (e) => {
    let linkTo = "";
    let value = e.target.value;
    if (value === "currentlyReading") {
      linkTo = "current-reading";
    } else if (value === "wantToRead") {
      linkTo = "want-to-read";
    } else if (value === "read") {
      linkTo = "read";
    } else {
      return;
    }
    update(props.value, value).then((res)=> {
      if(props.isUpdate){
        props.isUpdate()
      }
    }).catch((err)=>console.log(err))
    const el = document.getElementById(linkTo);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
   
  };
  return (
    <div>
      <div className="book">
        <div className="book-top">
          <div
            className="book-cover"
            style={{
              width: 128,
              height: 193,
              backgroundImage: `URL(${imageLinks.thumbnail})`,
            }}
          ></div>
          <div className="book-shelf-changer">
            <select onChange={(e) => handleOnSelect(e)} defaultValue={type}>
              <option value="none" disabled>
                Move to...
              </option>
              {options.length > 0 &&
                options.map((c, i) => (
                  <option key={i} value={c.value}>
                    {c.title}
                  </option>
                ))}
            </select>
          </div>
        </div>
        <div className="book-title">{title}</div>
        {authors?.map((v, i) => (
          <div key={i} className="book-authors">
            {v}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Card;
