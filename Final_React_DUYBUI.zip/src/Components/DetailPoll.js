import React from "react";
import { useParams, useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { add_Answer } from "../Redux/slices/questionSlice";
import { getQuestionHasVoted } from "../Utils/getQuestionType";
import { votePercentageCalculator } from "../Utils/getVote";
function DetailPoll() {
  const { question_id } = useParams()
  const history = useHistory();
  const dispatch = useDispatch();
  const questions = useSelector((state) => state.question.questions);
  const users = useSelector((state) => state.user.userInfo)
  const isQuestion = questions[question_id]
  const isAuthor = Object.values(users).find((v) => v.id === isQuestion?.author)
  const {id} = useSelector((state) => state.logged.isUserLogged) 
  const isAuthen = Object.values(users).find((v) => v.id === id)
  if (!isQuestion || !isAuthor || (!isAuthen)) {
    setTimeout(() => {
      history.push("/404")      
    }, 300);
  }
  
  const hasVoted = getQuestionHasVoted(isQuestion, isAuthen?.id)
  // Handle Add Answer
  const handleAddAnswer = (question_id, answer) => {
    let userId = isAuthen.id
    let obj = { userId, question_id, answer }
    dispatch(add_Answer(obj));
    setTimeout(() => {
      history.push("/questions/" + question_id)
    }, 500);
  }

  let showAnswer = ""
  let answer = isQuestion;
  if (answer?.optionOne?.votes?.includes(isAuthen?.id)) {
      showAnswer = answer.optionOne.text;
  } 
  if (answer?.optionTwo?.votes?.includes(isAuthen?.id)) {
      showAnswer = answer.optionTwo.text;
  } 
  return (
    <div>
      <section className="vh-100">
        <div className="container">
          <h1> The Poll Of {isAuthor?.name}</h1>
          <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col-md-12 col-xl-6">
              <div className="card mb-4">
                <div className="card-body text-center">
                  <div className="mt-3 mb-4">
                    <img
                      alt="This is img"
                      src={isAuthor?.avatarURL}
                      className="rounded-circle img-fluid"
                    />
                  </div>
                  <h4 className="mb-2"> Would You Rather</h4>
                  <h5 className="text-danger"> {hasVoted ? "My Answer:" + showAnswer : ""}</h5>

                  <div className="d-flex justify-content-between text-center mt-5 mb-4">
                    <div>
                      {!hasVoted ? (<div> <button
                        type="button"
                        className="btn btn-primary btn-rounded mr-4"
                        onClick={(e) => handleAddAnswer(question_id, "optionOne")}
                      >
                        {isQuestion?.optionOne?.text} <br /> <p className="fw-bold">(Click)</p>
                      </button> </div>) 
                      : (<> 
                        <button className={"btn " + (isQuestion?.optionOne?.votes.length > isQuestion?.optionTwo?.votes.length ? "btn-success" : "") }> 
                         {isQuestion?.optionOne?.text} <br />
                         <p className="fw-bold">Votes: {isQuestion?.optionOne?.votes.length} + ({votePercentageCalculator("optionOne", isQuestion)})</p>
                          </button>
                       </>)}


                    </div>
                    <div className="px-3"></div>
                    <div>
                    {!hasVoted ? (<div> <button
                        type="button"
                        className="btn btn-primary btn-rounded mr-4"
                        onClick={(e) => handleAddAnswer(question_id, "optionTwo")}
                      >
                        {isQuestion?.optionTwo?.text} <br /> <p className="fw-bold">(Click)</p>
                      </button> </div>) 
                      : (<> 
                         <button className={"btn " + (isQuestion?.optionTwo?.votes.length > isQuestion?.optionOne?.votes.length ? "btn-success" : "") }> 
                         {isQuestion?.optionTwo?.text} <br />
                         <p className="fw-bold">Votes: {isQuestion?.optionTwo?.votes.length} + ({votePercentageCalculator("optionTwo", isQuestion)})</p>
                          </button>
                       </>)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
export default DetailPoll;
