import RouterApp from "./Router/Route";
function App() {
  return (
    <div className="App">
      <div className="container">
        <RouterApp />
      </div>

    </div>
  );
}

export default App;
