import { render } from "@testing-library/react";
import NewPoll from "../Components/NewPoll";
import { Provider } from "react-redux";
import { store } from "../store";
import { BrowserRouter } from "react-router-dom";
import React from "react";
import { get_Questions } from "../Redux/slices/questionSlice";
import { get_InfoUser } from "../Redux/slices/userSlice";
import { loginPage } from "../Redux/slices/loginSlice";

describe("NewPoll component", () => {
  it("should render NewPoll component correctly", async () => {
    await store.dispatch(get_Questions());
    await store.dispatch(get_InfoUser());
    let auth = { id: "tylermcginnis" };
    await store.dispatch(loginPage(auth));
    const component = render(
      <Provider store={store}>
        <BrowserRouter>
          <NewPoll />
        </BrowserRouter>
      </Provider>
    );
    expect(component).toBeDefined();
  });
});
