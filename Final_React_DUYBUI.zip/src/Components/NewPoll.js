import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { add_Question } from "../Redux/slices/questionSlice";
import { useHistory } from "react-router-dom";
function NewPoll() {
    const [question, setQuestion] = useState({optionOne: "", optionTwo: ""});
    const dispatch = useDispatch();
    const history = useHistory();
    const isAuthor = useSelector((state) => state.logged.isUserLogged) 
    const handleSubmit = (e) => {
        e.preventDefault();
        let obj = {
            optionOneText: question.optionOne,
            optionTwoText: question.optionTwo,
            author: isAuthor.id
        }
        dispatch(add_Question(obj))
        history.push("/")
    }
    return (
        <div>
            <form onSubmit={(e)=>  handleSubmit(e)}>
                <div className="mb-3 mt-3">
                    <label htmlFor="ques_1" className="form-label">First Option</label>
                    <input type="text" className="form-control" placeholder="First Option" name="ques_1" onChange={(e)=> setQuestion({...question, optionOne: e.target.value})} />
                </div>
                <div className="mb-3">
                    <label htmlFor="ques_2" className="form-label">Second Option</label>
                    <input type="text" className="form-control" placeholder="Second Option" name="ques_1" onChange={(e)=> setQuestion({...question, optionTwo: e.target.value})} />
                </div>
                <button type="submit" className="btn btn-primary">Submit</button>
            </form>        </div>
    )
}

export default NewPoll;