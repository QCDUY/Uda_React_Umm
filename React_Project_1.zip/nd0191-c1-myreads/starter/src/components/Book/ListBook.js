import React, { useEffect, useState} from "react";
import { Link } from "react-router-dom";
import Bookshelf from "./Bookshelf";
import { getAll } from "../../BooksAPI";

function BookList() {
  const [data, setData] = useState([]);
  const [isUpdate, setIsUpdate] = useState(false);
  useEffect(() => {
    async function fetchAll() {
      let response = await getAll();
      setData(response);
    }
    return fetchAll()
  }, [isUpdate]);


  function setUpdateBook(){
    setIsUpdate(!isUpdate)
  }
  // List Book Shelf
  const shelfs = [
    { id: "currentlyReading", name: "Currently Reading" },
    { id: "wantToRead", name: "Want to Read" },
    { id: "read", name: "Read" },
  ];
  return (
    <div className="search-books">
      <div className="list-books">
        <div className="list-books-title">
          <h1>MyReads</h1>
        </div>
        <div className="list-books-content">
          {shelfs.map((v, i) => (
            <div key={i}>
              <Bookshelf
                bookshelfTitle={v.name}
                bookType={v.id}
                data={data}
                isUpdate={setUpdateBook}
              />
            </div>
          ))}
        </div>
        <div className="open-search">
          <Link to="/search">Add a book</Link>
        </div>
      </div>
    </div>
  );
}
export default BookList;
