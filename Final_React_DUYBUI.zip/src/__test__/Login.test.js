import "@testing-library/jest-dom";
import {fireEvent, render} from "@testing-library/react";
import {Provider} from "react-redux";
import {store} from "../store";
import {BrowserRouter} from "react-router-dom";
import React from "react";
import Login from "../Components/Login";
import { get_Questions } from "../Redux/slices/questionSlice";
import { get_InfoUser } from "../Redux/slices/userSlice";

describe("Login", () => {
    it("should render the component", () => {
        const component = render(
            <Provider store={store}>
                <BrowserRouter>
                    <Login/>
                </BrowserRouter>
            </Provider>
        );
        expect(component).toBeDefined();
        expect(component).toMatchSnapshot();
    });

    it('should clear input elements after clicking submit button', async () => {
        await store.dispatch(get_Questions());
        await store.dispatch(get_InfoUser());
        const wrapper = render(
            <Provider store={store}>
                <BrowserRouter>
                    <Login/>
                </BrowserRouter>
            </Provider>
        );

        const headerElement = wrapper.getByTestId("title");
        const inputELement = wrapper.getByTestId("userName");
        const passwordElement = wrapper.getByTestId("password");
        const buttonEl = wrapper.getByTestId("btn-login");
        expect(headerElement).toBeInTheDocument();
        expect(inputELement).toBeInTheDocument();
        expect(passwordElement).toBeInTheDocument();
        expect(buttonEl).toBeInTheDocument();

        fireEvent.change(inputELement, {target: {value: 'tylermcginnis'}});
        fireEvent.change(passwordElement, {target: {value: '99999999'}});
        expect(inputELement.value).toBe("tylermcginnis");
        expect(passwordElement.value).toBe("99999999");
        fireEvent.click(buttonEl);
        expect(inputELement.value).toBe("");
        expect(passwordElement.value).toBe("");
    });
});
