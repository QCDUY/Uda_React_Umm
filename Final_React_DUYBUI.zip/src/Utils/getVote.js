export function votePercentageCalculator(type, questions){
    let total = questions.optionOne.votes.length + questions.optionTwo.votes.length; 
    let per = "0%"
    if (type === "optionOne") {
        per = questions.optionOne.votes.length / total * 100 + " %";
    }
    if (type === "optionTwo") {
        per = questions.optionTwo.votes.length / total * 100 + " %";
    }
    return per
}