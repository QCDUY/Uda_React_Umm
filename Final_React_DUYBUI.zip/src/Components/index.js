import React from "react";
import { Route, Switch } from "react-router-dom";
import { useSelector } from "react-redux";
import PrivateRoute from "../Authentication/PrivateRoute";
import HomePage from "./Home";
import NewPoll from "./NewPoll";
import Login from "./Login";
import PageNotFound from "./PageNotFound";
import DetailPoll from "./DetailPoll";
import Header from "./Header";
import Leaderboard from "./Leaderboard";

const Index = () => {
  const isLogged = useSelector((state) => state.logged);
  return (
    <div>
      {isLogged?.isLogged ? <Header profile={isLogged.isUserLogged} /> : null}
      <Switch>
        <Route path="/login" component={Login} />
        <PrivateRoute path="/leaderboard" component={Leaderboard} />
        <PrivateRoute path="/questions/:question_id" component={DetailPoll} />
        <PrivateRoute path="/new" component={NewPoll} />
        <PrivateRoute path="/404"  component={PageNotFound} />
        <PrivateRoute path="/" exact component={HomePage} />
        <PrivateRoute path="*"  component={PageNotFound} />
      </Switch>

    </div>
  );
};
export default Index;
