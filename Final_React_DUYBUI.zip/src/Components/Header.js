import React from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { logoutPage } from "../Redux/slices/loginSlice";
import { useHistory } from "react-router-dom";

function Header(props) {
    const history = useHistory();
    const dispatch = useDispatch();
    const handleLogout = () => {
        localStorage.setItem("url404", false)
        localStorage.setItem("isLogged", false)
        localStorage.setItem("beforeUrl", "/")
        dispatch(logoutPage());
        history.push("/login")
    }
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                                <Link className="nav-link" to="/"> Home </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/leaderboard"> Leaderboard </Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/new"> New Poll </Link>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="/login" onClick={(e) => handleLogout()}> Logout ( Logged: {props?.profile?.name}) </a>
                            </li>
                        </ul>

                    </div>
                </div>
            </nav>
        </div>
    )
}
export default Header;