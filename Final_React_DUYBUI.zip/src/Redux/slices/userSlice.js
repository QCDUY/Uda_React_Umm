import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { _getUsers } from '../../Request/_DATA'
import { current } from '@reduxjs/toolkit'


export const get_InfoUser = createAsyncThunk('user/get-info', async (thunkAPI) => {
    try {
        const res = await _getUsers()
        return res
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})

export const add_AnswerUser = createAsyncThunk('user/add-answer-user', async (data, thunkAPI) => {
    try {
        return data
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})


export const add_QuestionUser = createAsyncThunk('user/add-question-user', async (data, thunkAPI) => {
    try {
        return data
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})

const initialState = {
    userInfo: [],
    isLoading: false
}

const userSlice = createSlice({
    name: 'info_user',
    initialState,
    extraReducers: builder => {
        builder.addCase(get_InfoUser.fulfilled, (state, action) => {
            state.isLoading = true
            state.userInfo = action.payload
        });
        builder.addCase(add_AnswerUser.fulfilled, (state, action) => {
            const { userId, question_id, answer } = action.meta.arg;
            let users = current(state.userInfo)
            let usr = {
                ...users,
                [userId]: {
                    ...users[userId],
                    answers: {
                        ...users[userId].answers,
                        [question_id]: answer
                    }
                }
            };
            state.userInfo = usr
        });
        builder.addCase(add_QuestionUser.fulfilled, (state, action) => {
            const { userId, question_id } = action.meta.arg;
            let users = current(state.userInfo)
            let usr = {
                ...users,
                [userId]: {
                  ...users[userId],
                  questions: users[userId].questions.concat(question_id)
                }
              };
            state.userInfo = usr
        })
    }
})
const { reducer } = userSlice;
export default reducer;