import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import { _getQuestions, _saveQuestionAnswer, _saveQuestion } from '../../Request/_DATA'
import { current } from '@reduxjs/toolkit'
import { add_AnswerUser, add_QuestionUser } from './userSlice'


export const get_Questions = createAsyncThunk('question/get-all', async(thunkAPI) => {
    try {
        const res = await _getQuestions()
        return res
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})

export const add_Answer = createAsyncThunk('questions/add-answer', async(data, thunkAPI) => {
   const {userId, question_id, answer} = data;
    try {
        const res = await _saveQuestionAnswer({
            authedUser: userId,
            qid: question_id,
            answer: answer
        })
        thunkAPI.dispatch(add_AnswerUser(data))
        return res
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})

export const add_Question = createAsyncThunk('questions/add-question', async(data, thunkAPI) => {
    const {optionOneText, optionTwoText, author} = data;
     try {
         const res = await _saveQuestion({optionOneText, optionTwoText, author})
         let obj = {
            userId: res.author, 
            question_id: res.id
         }
         thunkAPI.dispatch(add_QuestionUser(obj))
         return res
     } catch (err) {
         return thunkAPI.rejectWithValue(err)
     }
 })


const initialState = {
    questions: [],
    isLoading: false,
    msgErr: {},
}

const questionSlice = createSlice({
    name: 'info_questions',
    initialState,
    extraReducers: builder => {
        builder.addCase(get_Questions.fulfilled, (state, action) => {
            state.isLoading = true
            state.questions = action.payload
        });
        builder.addCase(add_Answer.fulfilled, (state, action) => {
            const {userId, question_id, answer} = action.meta.arg;
            let q = current(state.questions)
            let questions = {
                ...q,
                [question_id]: {
                  ...q[question_id],
                  [answer]: {
                    ...q[question_id][answer],
                    votes: q[question_id][answer].votes.concat([userId])
                  }
                }
              }
            state.questions = questions
        });
        builder.addCase(add_Question.fulfilled, (state, action) => {
            let q = current(state.questions)
            let questions = {
                ...q,
                [action.payload.id]: action.payload,
              };
            state.questions = questions
        });
    },
})
const { reducer } = questionSlice
export default reducer