# MyReads Project
In the "Employee Polls" Project, users will be able to answer polls, see which polls they haven’t answered, see how other people have voted, post polls, and see the ranking of users on the leaderboard.
# Author
- DUY BUI
- I'm developer

# Technical
ReactJS 

## TL;DR

To get started developing right away:

- install all project dependencies with `npm install`
- start the development server with `npm start`
- start unit test with `npm run test` or `npm test`

## What You're Getting

```bash
├── CONTRIBUTING.md
├── README.md - This file.
├── SEARCH_TERMS.md # The whitelisted short collection of available search terms for you to use with your app.
├── package.json # npm package manager file. It's unlikely that you'll need to modify this.
├── public
│   ├── favicon.ico # React Icon, You may change if you wish.
│   └── index.html # DO NOT MODIFY
└── src
    ├── Components # Contains Components
    │   ├── Card # Contains Polls 
    │   ├── DetaiPoll # Detail Poll You can vote  
    │   ├── Header # The NavBar 
    │   ├── Header.test.js # File unit test of NavBar 
    │   ├── Home # HomePage
    │   ├── Home.test.js # File unit test of HomePage
    │   ├── Index # Index Component
    │   ├── Leaderboard # Rank votes
    │   ├── Login # Login Page
    │   ├── Login.test.js # File unit test of Login Page
    │   ├── NewPoll # Create new a poll
    │   ├── NewPoll.test.js # File unit test of create new a poll
    │   ├── PageNotFound # 404
    ├── Redux # Contains Redux
    │   ├── loginSlice.js # Apply redux store data for login
    │   ├── questionsSlice.js # Apply redux store data for questions
    │   ├── userSlice.js # Apply redux store data for users
    ├── Request # Contains data
    │   ├── _DATA.js # Provide data for app and execute logic
    │   ├── _DATA.test.js # File test provide data for app and execute logic
    │   ├── httpRequest.js # Logic functions for users and questions 
    │   ├── userSlice.js # Apply redux store data for users
    ├── App.css # Styles for your app. Feel free to customize this as you desire.
    ├── App.js # This is the root of your app. Contains static HTML right now.
    ├── icons # Helpful images for your app. Use at your discretion.
    │   ├── add.svg
    │   ├── arrow-back.svg
    │   └── arrow-drop-down.svg
    ├── index.css # Global styles. You probably won't need to change anything here.
    └── index.js # You should not need to modify this file. It is used for DOM rendering only.
```

Remember that good React design practice is to create new JS files for each component and use import/require statements to include them where they are needed.

## Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app). You can find more information on how to perform common tasks [here](https://github.com/facebook/create-react-app/blob/main/packages/cra-template/template/README.md).

## Contributing

This repository is the starter code for _all_ Udacity students. Therefore, we most likely will not accept pull requests.

For details, check out [CONTRIBUTING.md](CONTRIBUTING.md).
