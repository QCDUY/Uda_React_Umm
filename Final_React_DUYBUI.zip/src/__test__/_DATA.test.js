import { _saveQuestionAnswer, generateUID, _saveQuestion } from "../Request/_DATA";
describe("_saveQuestionAnswer", () => {
    it("should return true if correct", async () => {
        const response = await _saveQuestionAnswer({
            authedUser: "tylermcginnis",
            qid: "8xf0y6ziyjabvozdd253nd",
            answer: "optionTwo"
        });

        expect(response).toBeTruthy();
    });
});

describe("_saveQuestion", () => {
    it(" show data after save question ", async () => {
        const data = {
            author: "DUY",
            optionOneText: "pass",
            optionTwoText: "fail"
        }
        const res = await _saveQuestion(data)
        const {author, optionOne, optionTwo} = res;
        let _one = optionOne.text;
        let _two = optionTwo.text;
        expect(author).toBe("DUY")
        expect(_one).toBe("pass")
        expect(_two).toBe("fail")
    })
});


describe("_saveQuestion", () => {
    it(" show message when save question error ", async () => {
        const data = {
            author: null,
            optionOneText: undefined,
            optionTwoText: undefined
        }
        await expect(_saveQuestion(data)).rejects.toEqual("Please provide optionOneText, optionTwoText, and author")
    })
});

describe("_saveQuestionAnswer", () => {
    it("should return true if correct", async () => {
        const response = await _saveQuestionAnswer({
            authedUser: undefined,
            qid: "8xf0y6ziyjabvozdd253nd",
            answer: null
        }).catch(e => e);

        expect(response).toBe("Please provide authedUser, qid, and answer");
    });
})


describe("generateUID", () => {
    it("should generateUID ", () => {
        let genIDOne = generateUID();
        let genIDTwo = generateUID();
        expect(genIDOne !== genIDTwo).toBe(true);
    });
})
