
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'

export const loginPage = createAsyncThunk('login', async (data, thunkAPI) => {
    try {
        localStorage.setItem("isLogged", true)
        return data
    } catch (err) {
        return thunkAPI.rejectWithValue(err)
    }
})


export const logoutPage = createAsyncThunk('logout', async (thunkAPI) => {
    return true
})

const initialState = {
    isUserLogged: {},
    isLogged: false,
}

const loginSlice = createSlice({
    name: 'logged',
    initialState,
    extraReducers: builder => {
        builder.addCase(loginPage.fulfilled, (state, action) => {
            state.isLogged = true
            state.isUserLogged = action.payload
        });
        builder.addCase(logoutPage.fulfilled, (state, action) => {
            state.isLogged = false
            state.isUserLogged = {}
        })
    }
})
const { reducer } = loginSlice
export default reducer