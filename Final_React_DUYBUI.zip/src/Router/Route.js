import React, { useEffect } from "react";
import { BrowserRouter } from "react-router-dom";
import Index from "../Components";
import { useDispatch } from "react-redux";
import { get_InfoUser } from "../Redux/slices/userSlice";
import { get_Questions } from "../Redux/slices/questionSlice";

function RouterApp() {
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(get_InfoUser());
        dispatch(get_Questions());
    }, [dispatch])
    return (
        <BrowserRouter>
            <Index />
        </BrowserRouter>
    );
}
export default RouterApp;