import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import { loginPage } from "../Redux/slices/loginSlice";
function Login() {
  const navigate = useHistory();
  const [auth, setAuth] = useState({ name: "sarahedo", password: "password123" });
  const users = useSelector((state) => state.user.userInfo);
  const dispatch = useDispatch();
  const onSubmitLogin = async (e) => {
    e.preventDefault();
    if (auth.name === null && auth.password === null) {
      return;
    }
    const authen = Object.values(users).find(
      (user) => user.id === auth.name && user.password === auth.password
    );
    if (authen) {
      await dispatch(loginPage(authen));
      let isErrorPage = localStorage.getItem("url404");
      let beforeUrl = localStorage.getItem("beforeUrl");
      if (isErrorPage === "true") {
        navigate.push(beforeUrl);
      } else {
        navigate.push("/");
      }
    } else {
      setAuth({ name: "", password: "" });
    }
    return true;
  };
  return (
    <div>
      <form onSubmit={(e) => onSubmitLogin(e)}>
        <h1 data-testid="title"> Login </h1>
        <div className="mb-3 mt-4">
          <label htmlFor="userName" className="form-label">
            UserName
          </label>
          <input
            type="text"
            value={auth.name}
            data-testid="userName"
            className="form-control"
            id="userName"
            aria-describedby="userName"
            onChange={(e) => setAuth({ ...auth, name: e.target.value })}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="password" className="form-label">
            Password
          </label>
          <input
            type="password"
            value={auth.password}
            data-testid="password"
            className="form-control"
            id="password"
            onChange={(e) => setAuth({ ...auth, password: e.target.value })}
          />
        </div>
        <button
          type="submit"
          data-testid="btn-login"
          id="btn-login"
          className="btn btn-primary"
        >
          Submit
        </button>
      </form>
    </div>
  );
}
export default Login;
