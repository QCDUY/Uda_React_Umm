import {_getQuestions, _getUsers, _saveQuestion, _saveQuestionAnswer} from "./_DATA";

export default {_getQuestions, _getUsers, _saveQuestion, _saveQuestionAnswer}