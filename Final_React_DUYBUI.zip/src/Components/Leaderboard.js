import React from "react";
import { useSelector } from "react-redux";

function Leaderboard() {
    const users = useSelector((state) => state.user.userInfo);
    let topUsers = Object.values(users).sort((a, b) => Object.keys(b.answers).length - Object.keys(a.answers).length);
    return (
        <div className="container mt-3">
            <h2> Leaderboard </h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Answered</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        topUsers.map(v => (
                            <tr key={v.id}>
                                <td>{v.name}</td>
                                <td>{Object.keys(v.answers).length}</td>
                                <td>{Object.keys(v.questions).length}</td>
                            </tr>
                        ))
                    }

                </tbody>
            </table>
        </div>
    )
}

export default Leaderboard;