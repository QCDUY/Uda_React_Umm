/**
 * The function to get question type [new or ans]
 * @param {*} questions 
 * @returns 
 */
export const getQuestionType = (questions, authenId) => {
    let newQuestions = []
    let answerQuestion = []
    for (let i in questions) {
        if (questions[i]?.optionOne?.votes.includes(authenId) || questions[i]?.optionTwo?.votes.includes(authenId)) {
            answerQuestion.push(questions[i])
        } else {
            newQuestions.push(questions[i])
        }

    }
    newQuestions = newQuestions.sort((a, b) => b.timestamp - a.timestamp);
    answerQuestion = answerQuestion.sort((a, b) => b.timestamp - a.timestamp);
    return { newQuestions, answerQuestion }
}

/**
 * 
 * @param {*} question 
 * @param {*} authenId 
 * @returns 
 */
export const getQuestionHasVoted = (question, authenId) => {
    if (question?.optionOne?.votes?.includes(authenId) || question?.optionTwo?.votes?.includes(authenId)) {
        return true
    }
    return false
}