import { configureStore } from '@reduxjs/toolkit';
import userReducer from './Redux/slices/userSlice';
import questionReducer from "./Redux/slices/questionSlice";
import loginReducer from "./Redux/slices/loginSlice";
const reducer = {
  user: userReducer,
  question: questionReducer,
  logged: loginReducer
}

export const store = configureStore({
  reducer: reducer,
})
