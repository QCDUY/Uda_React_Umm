import React from "react";
import { Route, Redirect } from "react-router-dom";
import { useSelector } from "react-redux";
// Custom Auth Route
const PrivateRoute = ({ component: Component, ...rest }) => {
  let { isLogged } = useSelector((state) => state.logged);
  if (!isLogged) {
    let isCheck = localStorage.getItem("isLogged");
    if (isCheck) {
      localStorage.setItem("isLogged", false);
      localStorage.setItem("url404", true);
    } else {
      isLogged = false;
    }
  }
  return (
    <Route
      {...rest}
      render={(props) => {
        localStorage.setItem("beforeUrl", props.location.pathname)
        return isLogged === true ? (
          <Component />
        ) : (
          <Redirect to={{ pathname: "/login", state: props.location }} />
        );
      }}
    />
  );
};
export default PrivateRoute;
